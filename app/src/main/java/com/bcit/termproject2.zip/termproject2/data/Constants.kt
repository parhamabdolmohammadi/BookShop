package com.bcit.lecture10bby.data.com.bcit.termproject2.data


const val BASE_URL = "https://www.googleapis.com/books/v1/volumes?q=%s"

